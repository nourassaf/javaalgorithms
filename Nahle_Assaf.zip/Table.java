import java.util.Vector;
import javax.swing.table.AbstractTableModel;

class Table extends AbstractTableModel{
        public static final int indexColumn=0;
        public static final int valueColumn=1;
        String[] arr;
        Vector data;
        
        public Table(String[] arr){
            this.arr=arr;
            this.data=new Vector();
        }
        public int getRowCount() {
            return data.size();
        }
        public int getColumnCount() {
            return arr.length;
        }
        public String ColName(int column){
            return arr[column];
        }
        public Object getValueAt(int rowIndex, int columnIndex) {
            Dataset ds =(Dataset)data.get(rowIndex);
            switch(columnIndex){
                case indexColumn: //0
                    return ds.getIndex();
                case valueColumn:  //1
                    return ds.getValue();
                default:
                    System.out.println("Invalid Index!");
                    return new Object();
            }
        }
        
        public void setValueAt(Object value, int rowIndex, int columnIndex){
            Dataset ds=(Dataset)data.get(rowIndex);
            switch(columnIndex){
                case indexColumn:
                    ds.setIndex((String) value);
                    break;
                case valueColumn:
                    ds.setValue(String.valueOf(value));
                    break;
                default:
                    System.out.println("Invalid Index");
                    break;
            }
            fireTableCellUpdated(rowIndex, columnIndex);
        }
        
        public boolean hasEmptyRow(){
            if (data.size()==0){
                return false;
            }else{
                return true;
            }            
        }
        
        public void addDataSet(String index, String value){
            Dataset ds=new Dataset();
            ds.setIndex(index);
            ds.setValue(value);
            data.add(ds);
            fireTableRowsInserted(data.size()-1, data.size()-1);
        }
        
        public void deleteAllRow(){
            data.removeAll(data);
        }
 
    }