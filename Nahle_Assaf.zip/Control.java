import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class Control {
    private View view;
    private Model model;
    
    public Control(Model model,View view){
        this.model = model;
        this.view = view;
        this.view.addComboBoxSelectListener(new selectOption());
        this.view.addSetArrayListener(new setArray());
        this.view.addComboBoxFilledNumbers(new fillednums());
        this.view.addFillRandomlyListener(new fillRandomly());
        this.view.addEmptyTableListener(new emptyTable());
        this.view.addFindListener(new find());
        this.view.addSortComboBoxListener(new selectedSortType());
        this.view.addSortListener(new sort());
    }
    
    class selectOption implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            JComboBox cb=(JComboBox)e.getSource();
            model.setArrayType((String)cb.getSelectedItem());
            System.out.println("Selected item is "+model.getArrayType());
        }
    }
    
    class setArray implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            model.setArraySize(view.getSizeArray());
        
            String index = "";
            String value = "";
            int arraySize;
            switch(model.getArrayType()){
                    case "Array":
                        model.deleteTable();
                        arraySize=model.getArraySize();
                        model.initialArr(arraySize);
                        view.updateTable(model.getMyModel(), model.getColumnNames());
                        break;
                    default:
                        System.out.println("error!");
                        break;
            }
        }
    }
    
    class fillednums implements ActionListener{
        public void actionPerformed(ActionEvent e) {            
            JComboBox cb=(JComboBox)e.getSource();
            model.setFilledNumbers((String)cb.getSelectedItem());
        }
    }
    
    class fillRandomly implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            model.deleteTable(); //delete the table if not empty
            int arraySize=model.getArraySize();
            String randomValue="";
            if (model.getFilledNumbers()=="Numbers from 0 to 9"){ //restriction so arrSize should be less than 11
                if (arraySize<11){
                    for (int i=0;i<arraySize;i++){
                        boolean notUnique;
                        do{
                            notUnique=false;
                            randomValue=String.valueOf((int)Math.floor(Math.random()*10));
                            if (i>0){
                                for (int j=0;j<=i-1;j++ ){
                                    if(model.getMyModel().getValueAt(j, 1).equals(randomValue)){ // unique numbers
                                        notUnique=true;
                                        break;
                                    }
                                }
                            }
                        }while(notUnique);                        
                        model.addRow(String.valueOf(i), randomValue);
                        view.updateTable(model.getMyModel(), model.getColumnNames());
                    }
                }else{
                    view.popUpMessage("You should select a Array Size between 1 and 10.");
                }
            }else if (model.getFilledNumbers()=="Numbers from 0 to 9 (identical nums allowed)"){
                fillRandomlyUpTo(10, arraySize);
            }else if(model.getFilledNumbers()=="Large numbers"){
                fillRandomlyUpTo(1000, arraySize);
            }else{
                view.popUpMessage("Use th kind of numbers you want the datastructre to be filled with.");
            }
        }   
    }
    
    private void fillRandomlyUpTo(int upToNumber, int arraySize){
        String randVal="";
        for (int i=0;i<arraySize;i++){
            randVal=String.valueOf((int)Math.floor(Math.random()*upToNumber));
            model.addRow(String.valueOf(i), randVal); // add the random number to the table
            view.updateTable(model.getMyModel(), model.getColumnNames()); // then update the view
        }
    }
    
    class emptyTable implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            model.deleteTable();
            int arraySize=model.getArraySize();
            for (int i=0;i<arraySize;i++){
                model.addRow(String.valueOf(i), ""); // replace every number by an empty string (emptying the table)
            }
        }
    }
    
    class find implements ActionListener{

        public void actionPerformed(ActionEvent e) {
           for (int i = 0; i < model.getArraySize(); i++) {
                int a = Integer.valueOf(String.valueOf(i));
                if (view.getValue()==a) {
                view.popUpMessage("Found and is in the array");
                }
            else{
                view.popUpMessage("Not Found");
            }
          }
    }
    }

    class selectedSortType implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            JComboBox cb=(JComboBox)e.getSource();
            model.setSortingAlgorithm((String)cb.getSelectedItem());
            System.out.println("Selected Sorting Algorthim is "+model.getSortingAlgorithm());
        }
        
    }
    
    class sort implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            //check for selected sorting algorithm
            String sortAlgo=model.getSortingAlgorithm();
            System.out.println(sortAlgo);
            model.outputClear();
            model.setOutput("\nIndex\t|Value");
            model.printOutArray();            
            switch(sortAlgo){
                case "Bubble Sort":
                    model.bubbleSort();
                    break;
                case "Insertion Sort":
                    System.out.println("Insertion Sort was selected");
                    model.insertionSort();
                    break;
                case "Selection Sort":
                    model.selectionSort();
                    break;
                case "Bucket Sort":
                    if (model.getFilledNumbers()!="big (up to 10 digit) numbers"){
                        model.bucketSort();
                    }else{
                        view.popUpMessage("Choose to fill in with numbers between 0 to 9!");                        
                    }
                    break;
                case "Radix Sort":
                    model.radixSort();
                    break;
                case "Merge Sort":
                    model.mergeSort();
                    break;
                default:
                    System.out.println("Please selet a sorting algorithm, in order to sort.");
                    view.popUpMessage("Please selet a sorting algorithm, in order to sort.");
                    break;
            }
            model.printOutArray();
            view.printOutTextArea(model.getOutput());
        }
    }
}
