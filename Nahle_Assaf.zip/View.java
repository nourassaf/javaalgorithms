import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
    
public class View extends JFrame {

    String[] dataStructureTypes={"", "Array"};
    String[] sorting={"", "Bubble Sort","Insertion Sort","Selection Sort", "Bucket Sort","Radix Sort","Merge Sort"};
    String[] filledNumbers={"", "Numbers from 0 to 9", "Numbers from 0 to 9 (identical nums allowed)","Large numbers"};
    
    private String[] columnNames= {"",""};
    
    protected Table myModel=new Table(columnNames);
   
    private JButton createarr=new JButton("Create Array");
    private JButton find=new JButton("Find");
    private JButton fill=new JButton("Random Filling");
    private JButton empty=new JButton("Empty Table");
    private JButton sort=new JButton("Sort");
    
    private JComboBox dataStructureList=new JComboBox(dataStructureTypes);
    private JComboBox fillednums=new JComboBox(filledNumbers);
    private JComboBox csorting=new JComboBox(sorting); 
    
    private JTextField arrsize=new JTextField(6);
    private JTextField textfield_val=new JTextField(6);
    private JTextField textfield_index=new JTextField(3);
    
    private JLabel label_size=new JLabel("Size");    
    private JLabel label_value=new JLabel("Value");   
    private JLabel label_index=new JLabel("Index");

    private JScrollPane scrollpane=new JScrollPane();
    private JTable table=new JTable();
       
    private JScrollPane jOutput=new JScrollPane();
    private JTextArea aOutput=new JTextArea();
    
    View(){
        JPanel panel=new JPanel();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        table.setModel(myModel);
        
        panel.add(dataStructureList);
        panel.add(label_size);
        panel.add(arrsize);
        panel.add(createarr);

        scrollpane=new JScrollPane();
        scrollpane.getViewport().add(table, null);
        Dimension d=table.getPreferredSize();
        scrollpane.setPreferredSize(new Dimension(d.width, 200));
        panel.add(scrollpane);
        
        panel.add(fillednums);
        panel.add(fill);
        panel.add(empty);
        panel.add(textfield_val);
        panel.add(label_value);
        panel.add(textfield_index);
        panel.add(label_index);
        panel.add(find);
        panel.add(csorting);
        panel.add(sort);        
        jOutput=new JScrollPane();
        jOutput.getViewport().add(aOutput, null);
        jOutput.setPreferredSize(new Dimension(600, 400));
        panel.add(jOutput);
        add(panel);
    }
    
    public int getSizeArray(){
        try{
            return Integer.parseInt(arrsize.getText());}
        catch(Exception ex){
            return 0;    
        }
    }
    
    public int getValue(){
        try{
        return Integer.parseInt(textfield_val.getText());
        }catch(Exception ex){
            return -10000000;
        }
    }
    
    public int getIndex(){
        try{
            return Integer.parseInt(textfield_index.getText());
        }catch (Exception ex){
            return -10000000;
        }
    }
  
    void addComboBoxSelectListener(ActionListener ListenForComboSelect){
        dataStructureList.addActionListener(ListenForComboSelect);
    }
    
    void addSetArrayListener(ActionListener ListenForButton){        
        createarr.addActionListener(ListenForButton);
    }
    
    void addComboBoxFilledNumbers(ActionListener ListenForComboSelect){
        fillednums.addActionListener(ListenForComboSelect);
    }
    
    void addFillRandomlyListener(ActionListener ListenForButton){
        fill.addActionListener(ListenForButton);
    }
    
    void addEmptyTableListener(ActionListener ListenForButton){
        empty.addActionListener(ListenForButton);
    }
    
    void addFindListener(ActionListener ListenForButton){
        find.addActionListener(ListenForButton);
    }

    void addSortComboBoxListener(ActionListener ListenForComboSelect){
        csorting.addActionListener(ListenForComboSelect);
    }
    
    void addSortListener(ActionListener ListenForButton){
        sort.addActionListener(ListenForButton);
    }
    
    public void printOutTextArea(String text){
        aOutput.append(text);
    }
    
    public void popUpMessage(String text){
        JOptionPane.showMessageDialog(this, text);                
    }
  
    public void updateTable(Table model, String[] columnNames){
        table.setModel(model);
        model=new Table(columnNames);
    }

    public String[] getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(String[] columnNames) {
        this.columnNames = columnNames;
    }
}