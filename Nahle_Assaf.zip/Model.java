import java.awt.List;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

public class Model {
    
    private String arr_type="";
    private int arr_size;
    private String fillednums="";
    private String sortingAlgo="";
    private String output="";
    private String[]  columnNames= {"Index","Content"};
    
    private Table model = new Table(columnNames);

    public String getArrayType() {
        return arr_type;
    }
    public void setArrayType(String arrayType) {
        this.arr_type = arr_type;
    }

    public int getArraySize() {
        return arr_size;
    }

    public void setArraySize(int arr_size) {
        this.arr_size = arr_size;
    }

    public String getFilledNumbers() {
        return fillednums;
    }

    public void setFilledNumbers(String fillednums) {
        this.fillednums = fillednums;
    }

    public String getSortingAlgorithm() {
        return sortingAlgo;
    }

    public void setSortingAlgorithm(String sortingAlgo) {
        this.sortingAlgo = sortingAlgo;
    }
    
    public void initialArr(int arr_size){
        for (int i=0; i<arr_size; i++){
            model.addDataSet(String.valueOf(i), "");
        }
    }
    
    public void addRow(String index, String value){
        model.addDataSet(index, value);
    }
// bubblesort
    public void bubbleSort(){
        output="\nThe array before sorting has the following numbers: ";
        for (int i = 0; i < arr_size; i++) {
            output+=model.getValueAt(i, 1)+" ";
        }
        for (int i = 0; i < arr_size-1; i++){
            for (int j=0; j < arr_size-i-1; j++){
                System.out.println("\n>> i of index "+i+" , we have: j of index "+j+" having a value of "+(String) model.getValueAt(j, 1)+" & j+1 of index "+(j+1)+" having a value of "+(String) model.getValueAt(j+1, 1));
                output+="\n>> i of index "+i+" , we have: j of index "+j+" having a value of "+(String) model.getValueAt(j, 1)+" & j+1 of index "+(j+1)+" having a value of "+(String) model.getValueAt(j+1, 1);
                if ( Integer.valueOf((String) model.getValueAt(j, 1)) > Integer.valueOf((String) model.getValueAt(j+1,1))){
                    swap(j,j+1);
                    System.out.println("\nSince "+(Integer.valueOf((String) model.getValueAt(j, 1))+" <= "+Integer.valueOf((String) model.getValueAt(j+1,1)))+ ",then both are swapped! The new position is j of index "+j+" and value of "+(String) model.getValueAt(j, 1)+" & j+1 of index "+(j+1)+" having a value of "+(String) model.getValueAt(j+1, 1));
                    output+= "\nSince "+(Integer.valueOf((String) model.getValueAt(j, 1))+" <= "+Integer.valueOf((String) model.getValueAt(j+1,1)))+ ", then both are swapped! The new position is j of index "+j+" and value of "+(String) model.getValueAt(j, 1)+" & j+1 of index "+(j+1)+" having a value of "+(String) model.getValueAt(j+1, 1)+"\n";
                }
            }
        }
    }
    
// selectionsort 
    public void selectionSort(){
        output="\nThe array before sorting has the following numbers: ";
        for (int i = 0; i < arr_size; i++) {
            output+=model.getValueAt(i, 1)+" ";
        }
        for (int i = 0; i < arr_size-1; i++){
            int min_index = i;
            for (int j = i+1; j < arr_size; j++){
                System.out.println(">> i of index "+i+" , we have: j of index "+j+" having value of "+(String) model.getValueAt(j, 1));
                output+="\n>> i of index "+i+" , we have: j of index "+j+" having value of "+(String) model.getValueAt(j, 1);
                if (Integer.valueOf((String) model.getValueAt(j, 1)) < Integer.valueOf((String) model.getValueAt(min_index,1))){
                    min_index = j;
                }
            }
            if (min_index != i)
                swap(i, min_index);
                System.out.println("\nSince "+Integer.valueOf((String) model.getValueAt(i, 1))+ " <= "+ Integer.valueOf((String) model.getValueAt(min_index, 1))+", then both are swapped! The new position is of index "+i+" having a value of "+(String) model.getValueAt(i, 1)+" & j+1 of index "+min_index+" having a value of "+(String) model.getValueAt(min_index, 1));
                output+="\nSince "+Integer.valueOf((String) model.getValueAt(i, 1))+ " <= "+ Integer.valueOf((String) model.getValueAt(min_index, 1))+", then both are swapped! The new position is of index "+i+" having a value of "+(String) model.getValueAt(i, 1)+" & j+1 of index "+min_index+" having a value of "+(String) model.getValueAt(min_index, 1)+"\n";
        }
    }
    // insertionsort
    public void insertionSort(){
        output="\nThe array before sorting has the following numbers: ";
        for (int i = 0; i < arr_size; i++) {
            output+=model.getValueAt(i, 1)+" ";
        }
        for (int i = 1; i < arr_size; i++){
            int j = i;
            String key = (String) model.getValueAt(j, 1);

            while(j > 0 && Integer.valueOf((String) model.getValueAt(j-1, 1)) > Integer.valueOf(key)){
                int a = Integer.valueOf((String) model.getValueAt(j-1, 1));
                int b = Integer.valueOf(key);
                model.setValueAt(model.getValueAt(j-1, 1), j, 1);
                
                System.out.println("\nSince "+a+" > "+b+", then both are swapped!");
                output+="\nSince "+a+" > "+b+", then both are swapped! Now, "+a+" has index "+ j+" and "+b+" has index "+ (j-1);
                j--;
            }
            model.setValueAt(key, j, 1);
            System.out.println("\n     end while loop       ");
            output+="\n     end while loop       ";
        }
    }
     public void mergeSort(){
        int current;
        int left;
        for (current = 1; current <= arr_size-1; current = 2*current) {
            for (left = 0; left < arr_size-1; left+= 2*current) {
               int mid = Math.min(left+current-1, arr_size-1);
               int right = Math.min(left+2*current-1, arr_size-1);
               merge(left, mid, right);
            }
        }
     }
      public void merge (int left, int mid, int right){
          int n1 = mid-left+1;
          int n2 = right - mid;
          int L[] = new int[n1];
          int R[] = new int[n2];
          for (int i = 0; i < n1; i++) {
              L[i]=Integer.valueOf((String) model.getValueAt(left+i, 1));
          }
          for (int j = 0; j < n2; j++) {
              R[j]=Integer.valueOf((String) model.getValueAt(mid+1+j, 1));
          }
          int i = 0;
          int j = 0;
          int k = 1;
          while(i<n1 && j<n2){
              if(L[i]<=R[j]){
                  model.setValueAt(model.getValueAt(k, 1), L[i], 1);
                  i++;
              }
              else{
                  model.setValueAt(model.getValueAt(k, 1), R[j], 1);
                  j++;
              }
              k++;
          }
          while (i<n1){
              model.setValueAt(model.getValueAt(k, 1), L[i], 1);
              i++;
              k++;
          }
          while (j<n2){
              model.setValueAt(model.getValueAt(k, 1), R[j], 1);
              j++;
              k++;
          }
      }
    private void merge(String... args){
        
        int m=0;
        for(String arg: args){
            model.setValueAt(arg, m, 1);
            m++;
        }
    }
    
    private ArrayList<String> modeltoArrayList(){
        ArrayList<String> a=new ArrayList<String>();
        for (int i=0; i<model.getRowCount(); i++){
            a.add((String)model.getValueAt(i,1));
        }
        
        return a;
    }
    
    //bucketsort
    public void bucketSort(){
        output="\nThe array before sorting has the following numbers: ";
        for (int i = 0; i < arr_size; i++) {
            output+=model.getValueAt(i, 1)+" ";
        }
        output+="\nEach number will be transfered to its respective bucket:\n";
        ArrayList<String> bucket_0 = new ArrayList<String>();
        ArrayList<String> bucket_1 = new ArrayList<String>();
        ArrayList<String> bucket_2 = new ArrayList<String>();
        ArrayList<String> bucket_3 = new ArrayList<String>(); 
        ArrayList<String> bucket_4 = new ArrayList<String>();
        ArrayList<String> bucket_5 = new ArrayList<String>();
        ArrayList<String> bucket_6 = new ArrayList<String>();
        ArrayList<String> bucket_7 = new ArrayList<String>(); 
        ArrayList<String> bucket_8 = new ArrayList<String>();
        ArrayList<String> bucket_9 = new ArrayList<String>();
        
        for (int i=0; i<model.getRowCount(); i++){            
            switch(Integer.valueOf((String)model.getValueAt(i, 1))){
                case 0:
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 0";                    
                    bucket_0.add((String) model.getValueAt(i, 1));
                    break;
                case 1:
                    bucket_1.add((String) model.getValueAt(i,1));
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 1";                    
                    break;
                case 2:
                    bucket_2.add((String) model.getValueAt(i,1));
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 2";                    
                    
                    break;
                case 3:
                    bucket_3.add((String) model.getValueAt(i,1));
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 3";                    
                    
                    break;
                case 4:
                    bucket_4.add((String) model.getValueAt(i,1));
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 4";                    
                    
                    break;
                case 5:
                    bucket_5.add((String) model.getValueAt(i,1));
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 5";                    
                    
                    break;
                case 6:
                    bucket_6.add((String) model.getValueAt(i,1));
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 6";                    
                    
                    break;
                case 7:
                    bucket_7.add((String) model.getValueAt(i,1));
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 7";                    
                    
                    break;
                case 8:
                    bucket_8.add((String) model.getValueAt(i,1));
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 8";                    
                    
                    break;
                case 9:
                    bucket_9.add((String) model.getValueAt(i,1));
                    output+="\n>> Index "+i+" of value "+model.getValueAt(i, 1) +" will be transferred into bucket 9";                    
                    
                    break;
                default:
                    break;
            }
        }     
        
        ArrayList<String> bucket_sorted = new ArrayList<String>();
        bucket_sorted.addAll(bucket_0);
        bucket_sorted.addAll(bucket_1);
        bucket_sorted.addAll(bucket_2);
        bucket_sorted.addAll(bucket_3);
        bucket_sorted.addAll(bucket_4);
        bucket_sorted.addAll(bucket_5);
        bucket_sorted.addAll(bucket_6);
        bucket_sorted.addAll(bucket_7);
        bucket_sorted.addAll(bucket_8);
        bucket_sorted.addAll(bucket_9);
        
        String[] bucket_sorted_arr = bucket_sorted.toArray(new String[bucket_sorted.size()]);
        merge(bucket_sorted_arr);
    }
    private int numDigit=0;
    
    public void radixSort(){
        numDigit=3;
        String[] bucketsorted_arr=(SortRadix(numDigit, modeltoArrayList())).toArray(new String[model.getRowCount()]);
        merge(bucketsorted_arr);        
    }

    private ArrayList<String> SortRadix(int digit, ArrayList<String> arr){
     
         ArrayList<String> bucket_sorted = new ArrayList<String>();
        output="\nThe array before sorting has the following numbers: ";
        for (int i = 0; i < arr_size; i++) {
            output+=model.getValueAt(i, 1)+" ";
        }
        
         if (digit==0)
            return arr;
         else{
            ArrayList<String> bucket_0 = new ArrayList<String>();
            ArrayList<String> bucket_1 = new ArrayList<String>();
            ArrayList<String> bucket_2 = new ArrayList<String>();
            ArrayList<String> bucket_3 = new ArrayList<String>(); 
            ArrayList<String> bucket_4 = new ArrayList<String>();
            ArrayList<String> bucket_5 = new ArrayList<String>();
            ArrayList<String> bucket_6 = new ArrayList<String>();
            ArrayList<String> bucket_7 = new ArrayList<String>(); 
            ArrayList<String> bucket_8 = new ArrayList<String>();
            ArrayList<String> bucket_9 = new ArrayList<String>();

            for (int i=0; i<arr.size(); i++){
                String[] radix=(arr.get(i).split(""));
                System.out.println("String is "+arr.get(i));
                System.out.println("lenght is  "+(radix.length-1));
                int digi=numDigit!=radix.length-1?digit-(numDigit-(radix.length-1)):digit;
                
                String nthDigit;
                try{
                    nthDigit=radix[digi].equals("")?"0": String.valueOf(radix[digi]);
                }catch(Exception ex){
                    nthDigit="0";
                }
                
                System.out.println("Into bucket "+nthDigit);
                switch(nthDigit){
                    case "":
                    case "0":
                        bucket_0.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 0 because it ends with a zero.";
                        break;
                    case "1":
                        bucket_1.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 1 because it ends with 1";
                        break;
                    case "2":
                        bucket_2.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 2 because it ends with 2";
                        break;
                    case "3":
                        bucket_3.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 3 because it ends with 3";
                        break;
                    case "4":
                        bucket_4.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 4 because it ends with 4";
                        break;
                    case "5":
                        bucket_5.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 5 because it ends with 5";
                        break;
                    case "6":
                        bucket_6.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 6 because it ends with 6";
                        break;
                    case "7":
                        bucket_7.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 7 because it ends with 7";
                        break;
                    case "8":
                        bucket_8.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 8 because it ends with 8";
                        break;
                    case "9":
                        bucket_9.add(arr.get(i));
                        output+=arr.get(i)+"is added to bucket 9 because it ends with 9";
                        break;
                    default:
                        System.out.println("case doesn't exist");
                        break;
                }
             
                output="\nThe array now has become: ";
                for (int j = 0; j < arr.size(); j++) {
                output+=arr.get(j)+" ";
                }
            }
            bucket_sorted.addAll(bucket_0);
            bucket_sorted.addAll(bucket_1);
            bucket_sorted.addAll(bucket_2);
            bucket_sorted.addAll(bucket_3);
            bucket_sorted.addAll(bucket_4);
            bucket_sorted.addAll(bucket_5);
            bucket_sorted.addAll(bucket_6);
            bucket_sorted.addAll(bucket_7);
            bucket_sorted.addAll(bucket_8);
            bucket_sorted.addAll(bucket_9);
            System.out.println("-----------"+digit+"-------------------");
            return SortRadix(digit-1, bucket_sorted);
         }
     }

    private void swap(int temp, int i){
        int a = Integer.valueOf((String)model.getValueAt(temp, 1));
        model.setValueAt(model.getValueAt(i, 1), temp, 1);
        model.setValueAt(a, i, 1);
    }
    
    public void printOutArray(){
        for (int i=0; i<arr_size; i++){
            System.out.println(i+" | "+(String) model.getValueAt(i, 1));
            output+="\n"+i+" | "+(String) model.getValueAt(i, 1);
        }
    }
    
    public void deleteTable(){
        model.deleteAllRow();
    }

    public Table getMyModel() {
        return model;
    }

    public void setMyModel(Table model) {
        this.model = model;
    }

    public String[] getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(String[] columnNames) {
        this.columnNames = columnNames;
    }
    
    void addPrintOutput(ActionListener a){
        
    }

    public String getOutput() {
        return output;
    }

    public void setOutput(String output) {
        this.output = output;
    }
    
    public void outputClear(){
        output="";
    }
}