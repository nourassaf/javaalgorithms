public class MainClass {
     public static void main(String[] args) {
        View view = new View();
        Model model = new Model();
        Control c = new Control(model, view);
        
        view.updateTable(model.getMyModel(), model.getColumnNames());
        view.setVisible(true);
        view.setSize(750,750);
    }
}
